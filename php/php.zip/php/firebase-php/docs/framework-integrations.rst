######################
Framework Integrations
######################

kreait provides and maintains the following framework integrations for the Firebase Admin SDK for PHP:

*******
Laravel
*******

`kreait/laravel-firebase <https://github.com/kreait/laravel-firebase>`_

*******
Symfony
*******

`kreait/firebase-bundle <https://github.com/kreait/firebase-bundle>`_

***********
CodeIgniter
***********

`tatter/firebase <https://github.com/tattersoftware/codeigniter4-firebase>`_
