Thank you for considering to contribute to this project.

Please don't introduce changes without talking about them to the 
repository maintainers first - this way we can avoid that you 
put your valuable time and effort into a Pull Request that 
eventually could not be merged.

If you want to provide a bugfix, please include tests to 
prove that the bug exists and that it is fixed.

